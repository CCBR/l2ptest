

/*
vi a2a.c ; gcc -minline-all-stringops -Wall -Os -o a2a a2asupport.c a2a.c
fast way:
gcc -c -o -Os a2asupport.o a2asupport.c
gcc -minline-all-stringops -Wall -Os -o a2a a2asupport.o a2a.c

*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <limits.h>
#include <math.h>
#include <ctype.h>
#include <errno.h>

#include "pathworks.h"

#ifdef L2P_USING_R
#include <R.h>
#include <Rdefines.h>
#endif


extern struct ens2gene_type ens2gene[];
extern struct a2a_type a2a[];
struct an_type
{
    char *name;
    unsigned int taxid;
};

struct an_type animals[] =
{
    { "canis familiaris" ,  9615 } ,
    { "danio rerio" , 7955 } ,
    { "drosophila melanogaster" ,  7227 } ,
    { "homo sapiens" , 9606 } ,
    { "macaca mulatta" , 9544 } ,
    { "mus musculus" , 10090 } ,
    { "oryctolagus cuniculus" , 9986 } ,
    { "pan troglodytes" , 9598 } ,
    { "rattus norvegicus" , 10116 } ,
    { (char *)0 , 0}
};

inline static int an2taxid(const char s[])
{
    int i;
#define MAXLOCALSTRING 100     
    char t[MAXLOCALSTRING];

    t[0] = (char)0;
    for(i=0; s[i] && (i < (MAXLOCALSTRING-2) ) ; i++) 
    {
        t[i] = tolower(s[i]); // convert string to lower case
        t[i+1] = (char)0;
    }

// printf("in an2taxid [%s]\n",t); 
    if (strcmp(t,"dog") == 0)              strcpy(t,"canis familiaris");
    else if (strcmp(t,"zebrafish") == 0)   strcpy(t,"danio rerio");
    else if (strcmp(t,"fly") == 0)         strcpy(t,"drosophila melanogaster");
    else if (strcmp(t,"fruitfly") == 0)    strcpy(t,"drosophila melanogaster");
    else if (strcmp(t,"human") == 0)       strcpy(t,"homo sapiens");
    else if (strcmp(t,"homosapiens") == 0) strcpy(t,"homo sapiens");
    else if (strcmp(t,"rhesus") == 0)      strcpy(t,"macaca mulatta");
    else if (strcmp(t,"macaca") == 0)      strcpy(t,"macaca mulatta");
    else if (strcmp(t,"macaque") == 0)     strcpy(t,"macaca mulatta");
    else if (strcmp(t,"monkey") == 0)      strcpy(t,"macaca mulatta");
    else if (strcmp(t,"mouse") == 0)       strcpy(t,"mus musculus");
    else if (strcmp(t,"rabbit") == 0)      strcpy(t,"oryctolagus cuniculus");
    else if (strcmp(t,"chimp") == 0)       strcpy(t,"pan troglodytes");
    else if (strcmp(t,"chimpanzee") == 0)  strcpy(t,"pan troglodytes");
    else if (strcmp(t,"rat") == 0)         strcpy(t,"rattus norvegicus");
    for (i=0;animals[i].name;i++)
    {
        if (strcmp(t,animals[i].name) == 0) return animals[i].taxid;
    }
fprintf(stderr,"ERROR invalid species %s [%s]\n",t,t);
    return -1;
}

#if 0
static inline int fast_compare( const char *ptr0, const char *ptr1, int len )
{ // from https://mgronhol.github.io/fast-strcmp/
  int fast = len/sizeof(size_t) + 1;
  int offset = (fast-1)*sizeof(size_t);
  int current_block = 0;

  if( len <= sizeof(size_t)){ fast = 0; }


  size_t *lptr0 = (size_t*)ptr0;
  size_t *lptr1 = (size_t*)ptr1;

  while( current_block < fast ){
    if( (lptr0[current_block] ^ lptr1[current_block] )){
      int pos;
      for(pos = current_block*sizeof(size_t); pos < len ; ++pos ){
        if( (ptr0[pos] ^ ptr1[pos]) || (ptr0[pos] == 0) || (ptr1[pos] == 0) ){
          return  (int)((unsigned char)ptr0[pos] - (unsigned char)ptr1[pos]);
          }
        }
      }

    ++current_block;
    }

  while( len > offset ){
    if( (ptr0[offset] ^ ptr1[offset] )){ 
      return (int)((unsigned char)ptr0[offset] - (unsigned char)ptr1[offset]); 
      }
    ++offset;
    }
	
	
  return 0;
}
#endif

#if 1
#define STR_CMP(A,B) strcmp(A,B)
#else
#define STR_CMP(A,B) fast_compare(A,B)
#endif


#ifdef L2P_USING_R

SEXP a2afunc(SEXP lst,SEXP an1arg, SEXP an2arg)
{
    SEXP ret;
    int i,j,k;
    int foundcnt = 0;
    int len = 0;
    int len2 = 0;
    char **z = (void *)0;      // input mouse gene symbols
    char **z2 = (void *)0;     // output human gene symbols
    int outcnt = 0;
    int taxid1 =0;    // taxonomy ikd
    int taxid2 =0;
    int fixed_len = 0;
    char an1[PATH_MAX];
    char an2[PATH_MAX];


    memset(an1,0,sizeof(an1));
    strncpy(an1,CHAR(STRING_ELT(an1arg, 0)),PATH_MAX-2);
    taxid1=an2taxid(an1);

    memset(an2,0,sizeof(an1));
    strncpy(an2,CHAR(STRING_ELT(an2arg, 0)),PATH_MAX-2);
    taxid2=an2taxid(an2);

    len = length(lst);
    len2 = (len * 3) + 1000;

// fprintf(stderr,"debug: in a2afunc() len=%d taxid=%d taxid2=%d\n",len,taxid1, taxid2); fflush(stderr); 
    z = (char **)malloc(sizeof(char *)*len);
    if (!z)
    {
        fprintf(stderr,"ERROR out of memory in a2a(), input len is %d\n",len);
	return (SEXP)R_NilValue;
    }
	     
    for (i = 0; i < len; i++) *(z+i) = (void *)0;
    for (i = 0; i < len; i++) 
    {
       if (strlen(CHAR(STRING_ELT(lst, i))))
       {
          *(z+fixed_len) = strdup(CHAR(STRING_ELT(lst, i))); // malloc , be sure to free
	  fixed_len++;
       }
       else
       {
           fprintf(stderr,"WARNING: bad input dropped\n");
           fprintf(stderr,"bad element is at index = %d \n",i);
       }
    }

    z2 = (char **)malloc(sizeof(char *)*len2);
    if (!z2)
    {
        fprintf(stderr,"ERROR out of memory in a2a(), allocating results array.\n"); 	     
	if (z) free(z);
	return (SEXP)R_NilValue;
    }
    for (i = 0; i < len2; i++) *(z2+i) = (void *)0;

    outcnt = 0;
    for (j=0 ; j<fixed_len ; j++)
    {
        for (i=0 ; a2a[i].taxid1 != 0; i++)
        {
            if ( ( (taxid1 == a2a[i].taxid1) && (taxid2 == a2a[i].taxid2) ) || 
                 ( (taxid1 == a2a[i].taxid2) && (taxid2 == a2a[i].taxid1) ) 
               )
            {
                if (taxid1 == a2a[i].taxid1)
                {
                    if (STR_CMP(*(z+j),ens2gene[a2a[i].ensidx1].symbol) == 0)
                    {
                        *(z2+outcnt) = strdup(ens2gene[a2a[i].ensidx2].symbol); // malloc ,  be sure to free
                        foundcnt++;
                        outcnt++;
#if 0
			break;
#endif
                    }
                }
                else if (taxid1 == a2a[i].taxid2)
                {
                    if (STR_CMP(*(z+j),ens2gene[a2a[i].ensidx2].symbol) == 0)
                    {
                        *(z2+outcnt) = strdup(ens2gene[a2a[i].ensidx1].symbol); // malloc ,  be sure to free
                        foundcnt++;
                        outcnt++;
#if 0
			break;
#endif
                    }
                }
            }
        }
        if (outcnt >= len2)
        { 
            fprintf(stderr,"ERROR reached outcnt=%d, buffer overflow in a2a(), incnt=%d\n",len2,fixed_len); 
            fflush(stderr); 
            break;
	}
    }

    if (z) 
    { 
        for (k=0 ; k<fixed_len ; k++) 
	{ 
	    if (*(z+k)) free(*(z+k)); 
	}
	free(z); 
	z = (void *)0;  
    }

    PROTECT(ret = allocVector(STRSXP, outcnt));

    for (i = 0; i < outcnt; i++) 
    {
        if (*(z2+i)) { SET_STRING_ELT(ret,i, mkChar(*(z2+i)));}
    }
    if (z2) 
    { 
        for (k=0 ; k<outcnt ; k++) 
	{ 
	    if (*(z2+k)) free(*(z2+k)); 
	}
	free(z2); 
	z2 = (void *)0;  
    }
    UNPROTECT(1);

    return ret;
}

#if 0
SEXP a2afunc_many(SEXP lst,SEXP an1arg, SEXP an2arg)
{
    SEXP ret;
    int i,j,k;
    int foundcnt = 0;
    int len = 0;
    int len2 = 0;
    char **z = (void *)0;      // input mouse gene symbols
    char **z2 = (void *)0;     // output human gene symbols
    int outcnt = 0;
    int taxid1 =0;    // taxonomy ikd
    int taxid2 =0;
    int fixed_len = 0;
    char an1[PATH_MAX];
    char an2[PATH_MAX];

    strncpy(an1,CHAR(STRING_ELT(an1arg, 0)),PATH_MAX-2);
    strncpy(an2,CHAR(STRING_ELT(an2arg, 0)),PATH_MAX-2);
    taxid1=an2taxid(an1);
    taxid2=an2taxid(an2);
    len = length(lst);
    len2 = (len * 3) + 1000;

// fprintf(stderr,"debug: in a2afunc() len=%d taxid=%d taxid2=%d\n",len,taxid1, taxid2); fflush(stderr); 
    z = (char **)malloc(sizeof(char *)*len);
    if (!z)
    {
        fprintf(stderr,"ERROR out of memory in a2a(), input len is %d\n",len);
	return (SEXP)R_NilValue;
    }
	     
    for (i = 0; i < len; i++) *(z+i) = (void *)0;
    for (i = 0; i < len; i++) 
    {
       if (strlen(CHAR(STRING_ELT(lst, i))))
       {
          *(z+fixed_len) = strdup(CHAR(STRING_ELT(lst, i))); // malloc , be sure to free
	  fixed_len++;
       }
       else
       {
           fprintf(stderr,"WARNING: bad input dropped\n");
           fprintf(stderr,"bad element is at index = %d \n",i);
       }
    }

    z2 = (char **)malloc(sizeof(char *)*len2);
    if (!z2)
    {
        fprintf(stderr,"ERROR out of memory in a2a(), allocating results array.\n"); 	     
	if (z) free(z);
	return (SEXP)R_NilValue;
    }
    for (i = 0; i < len2; i++) *(z2+i) = (void *)0;

    outcnt = 0;
    for (j=0 ; j<fixed_len ; j++)
    {
        for (i=0 ; a2a[i].taxid1 != 0; i++)
        {
            if ( ( (taxid1 == a2a[i].taxid1) && (taxid2 == a2a[i].taxid2) ) || 
                 ( (taxid1 == a2a[i].taxid2) && (taxid2 == a2a[i].taxid1) ) 
               )
            {
                if (taxid1 == a2a[i].taxid1)
                {
                    if (strcmp(*(z+j),ens2gene[a2a[i].ensidx1].symbol) == 0)
                    {
                        *(z2+outcnt) = strdup(ens2gene[a2a[i].ensidx2].symbol); // malloc ,  be sure to free
foundcnt++;
                        outcnt++;
                    }
                }
                else if (taxid1 == a2a[i].taxid2)
                {
                    if (strcmp(*(z+j),ens2gene[a2a[i].ensidx2].symbol) == 0)
                    {
                        *(z2+outcnt) = strdup(ens2gene[a2a[i].ensidx1].symbol); // malloc ,  be sure to free
foundcnt++;
                        outcnt++;
                    }
                }
            }
        }
        if (outcnt >= len2)
        { 
            fprintf(stderr,"ERROR reached outcnt=%d, buffer overflow in a2a(), incnt=%d\n",len2,fixed_len); 
            fflush(stderr); 
            break;
	}
    }

    if (z) 
    { 
        for (k=0 ; k<fixed_len ; k++) 
	{ 
	    if (*(z+k)) free(*(z+k)); 
	}
	free(z); 
	z = (void *)0;  
    }

    PROTECT(ret = allocVector(STRSXP, outcnt));

    for (i = 0; i < outcnt; i++) 
    {
        if (*(z2+i)) { SET_STRING_ELT(ret,i, mkChar(*(z2+i)));}
    }
    if (z2) 
    { 
        for (k=0 ; k<outcnt ; k++) 
	{ 
	    if (*(z2+k)) free(*(z2+k)); 
	}
	free(z2); 
	z2 = (void *)0;  
    }
    UNPROTECT(1);
    return ret;

#if 0
   PROTECT(mychar = allocVector(STRSXP, 1));
   SET_STRING_ELT(mychar, 0, mkChar("AAA"));
   UNPROTECT(1);
   return mychar;
#endif
}
#endif


#else

 // command line
int a2afunc_command_line(int taxid1, int taxid2)
{
    char nm[512]; // gene name
    int i,status;
    int outcnt = 0;

    while ( fgets(nm, sizeof(nm), stdin) ) // gets() function is deprecated
    {
        for (i=0;nm[i];i++) { if ((nm[i] == '\r') || (nm[i] == '\n')) nm[i] = (char)0; }
        status = 0;
// fprintf(stderr,"here 2 %s\n",nm); fflush(NULL); 
        for (i=0 ; a2a[i].taxid1; i++)
        {    // h fields are : int hid; int taxid; int egid; char *sym;
#if 0
fprintf(stderr,"here 3 %s %s %s %s\n",
ens2gene[a2a[i].ensidx1].symbol,ens2gene[a2a[i].ensidx1].ens,
ens2gene[a2a[i].ensidx2].symbol,ens2gene[a2a[i].ensidx2].ens);
#endif
// xxx 
            if ( ( (taxid1 == a2a[i].taxid1) && (taxid2 == a2a[i].taxid2) ) || 
                 ( (taxid1 == a2a[i].taxid2) && (taxid2 == a2a[i].taxid1) ) 
               )
            {
                if (taxid1 == a2a[i].taxid1)
                {
// example line ; {9606,10090,85056,45585}
                    if (STR_CMP(nm,ens2gene[a2a[i].ensidx1].symbol) == 0)
                    {
// fprintf(stderr,"found 1 at %d %s %s %s\n",i,nm,ens2gene[a2a[i].ensidx1].symbol,ens2gene[a2a[i].ensidx2].ens);
    	                printf("%s\n",ens2gene[a2a[i].ensidx2].symbol);
                    }
                }
                else if (taxid1 == a2a[i].taxid2)
                {
                    if (STR_CMP(nm,ens2gene[a2a[i].ensidx2].symbol) == 0)
                    {
// fprintf(stderr,"found 2 at %d %s %s %s\n",i,nm,ens2gene[a2a[i].ensidx1].symbol,ens2gene[a2a[i].ensidx1].ens);
	                printf("%s\n",ens2gene[a2a[i].ensidx1].symbol);
                    }
                }
                outcnt++;
            }
        }
    }
    return status;
}

int main(int argc,char *argv[])
{
    char an1[512]; // source animal
    char an2[512]; // convert to this
    int taxid1;
    int taxid2;

    if (argc != 3)
    {
        fprintf(stderr,"usage: a2a genename source_species destination_species\n");
        return 1;
    }
    strcpy(an1,argv[1]);
    strcpy(an2,argv[2]);

    taxid1 = an2taxid(an1);
    taxid2 = an2taxid(an2);
    a2afunc_command_line(taxid1,taxid2);

    return 0;
}
#endif

