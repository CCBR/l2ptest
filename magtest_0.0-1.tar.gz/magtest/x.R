library(magtest)
magfunc()
