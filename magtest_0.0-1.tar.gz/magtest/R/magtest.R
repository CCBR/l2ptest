
magfunc <- function()
{
    result = 13.0
    return (result)
}

