
l2psuppver <- function()
{
    result = 13.0
    return (result)
}

o2o <- function(genes,animal_source,animal_dest)
{
# Arguments:
# genes : list of source gene symbols
    ugenes=unique(genes)
    RetVec2 = .Call(getNativeSymbolInfo("a2afunc"),ugenes,animal_source,animal_dest)
    return(RetVec2 )
}

a2a <- function(genes,animal_source,animal_dest)  # renamed to o2o , leave as convenience funtion
{
    ugenes=unique(genes)
    return(o2o(ugenes,animal_source,animal_dest))
}

#a2amany <- function(genes,animal_source,animal_dest)
#{
## Arguments:
## genes : list of source gene symbols
#    ugenes=unique(genes)
#    RetVec2 = .Call(getNativeSymbolInfo("a2afunc_many"),ugenes,animal_source,animal_dest)
#    return(RetVec2 )
#}

m2h <- function(b)
{
# Arguments:
# b : list of mouse gene symbols
    zz=unique(b)
    RetVec2 = .Call(getNativeSymbolInfo("a2afunc"),zz,"mouse","human")
}


updategenes <- function(genes,...)
{
# Arguments:
# genes : list of source gene symbols
    trust=1
    legitonly=0
    args <- list(...)

    genes=unique(genes)
    if ("trust" %in% names(args))
    {
        trust=args$trust
        RetVec1 = .Call(getNativeSymbolInfo("updategenes"),genes,trust)
        return(RetVec1)
    }
    if ("legitonly" %in% names(args))
    {
        legitonly=args$legitonly
               # first pass, update gene names
        RetVec1 = .Call(getNativeSymbolInfo("updategenes"),genes,0)  # dont trust, just get 1st col
#print(RetVec1)
        y= RetVec1[,"newname"]
#print("y newname");
#print(y)
        RetVec1 = .Call(getNativeSymbolInfo("updategenes"),y,0)
        y= RetVec1[RetVec1$is_legit_name == 1, ]
        y= y[,"newname"]
        return(y)
    }
    RetVec1 = .Call(getNativeSymbolInfo("updategenes"),genes,0)
    return(RetVec1)
}

egids2hugos <- function(egid_list,...)
{
# Arguments:
# egid_list : list of source gene symbols
    futureparam=1
    args <- list(...)

    a<-as.integer(egid_list)
    uniq_egids=unique(a)
    RetVec1 = .Call(getNativeSymbolInfo("egids2hugosR"),uniq_egids)
#SEXP gids2hugosR(SEXP ingenelist) //, SEXP trust_flag_arg)
    return(RetVec1)
}

